(function(){
	'use strict';
	
	angular
	.module('app', [])
	.controller('ProfilesController', ProfilesController);
	
	ProfilesController.$inject = ['$http'];
	
	function ProfilesController($http){
		var vm = this;
		
		vm.profiles = [];
		vm.getAll = getAll;
		vm.deleteProfile = deleteProfile;
		vm.addProfile = addProfile;
		
		init();
		
		function init(){
			getAll();
		}
		
		function getAll(){
			var url = "/profiles/all";
			var profilesPromise = $http.get(url);
			profilesPromise.then(function(response){
				vm.profiles = response.data;
			});
		}
		
		
		function deleteProfile(id){
			var url = "profiles/delete/" + id;
			$http.post(url).then(function(response){
				vm.profiles = response.data;
			});
		}
		
		function addProfile(){
			var url= "/profiles/create";
			$http.post(url).then(function(reponse){
				vm.profiles = response.data;
			})
		}
	}
})();