package org.LachlanGardner.Identity.Management;


import java.util.Arrays;
import java.util.List;

import org.LachlanGardner.Identity.Management.Profile;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;


@Component
public class DbSeeder implements CommandLineRunner{
	private ProfileRepository profileRepository;
	
	@Autowired
	public DbSeeder(ProfileRepository profileRepository) {
		this.profileRepository = profileRepository;
	}
	
	@Override
	public void run(String...strings) throws Exception{
		
		Profile Lachlan = new Profile("Lachlan", "Gardner", "lachy", "gardner", "lachlan.gardner2@hotmail.com", "admin");
		Profile Declan = new Profile("Declan", "Roberts", "dec", "rob", "declan.roberts@hotmail.com", "normal");
		Profile Kobby = new Profile("Kobby", "Agyei", "kobz", "agyei", "kobby.agyei@hotmail.com", "normal");
		Profile Ryan = new Profile("Ryan", "Lee", "ryan", "lee", "ryan.lee@hotmail.com", "normal");
		Profile Daniel = new Profile("Daniel", "Attuell", "dan", "attuel", "daniel.attuell@hotmail.com", "normal");
		
		
		// drop all profiles
		this.profileRepository.deleteAll();
				
		// add profiles to database
		List<Profile> profiles = Arrays.asList(Lachlan, Declan, Kobby, Ryan, Daniel);
		this.profileRepository.saveAll(profiles);
	}
}
