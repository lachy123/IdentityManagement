package org.LachlanGardner.Identity.Management;

import java.util.List;


import org.LachlanGardner.Identity.Management.ProfileRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping(value = "/profiles")
public class ProfileController {
	
private ProfileRepository profileRepository;
	
	@Autowired
	public ProfileController(ProfileRepository profileRepository) {
		this.profileRepository = profileRepository;
	}
	
	public ProfileController() {
		
	}
	
	@RequestMapping(value="/all", method = RequestMethod.GET)
	public List<Profile> getAll(){
		return profileRepository.findAll();
	}
	
	@RequestMapping(value="/create", method=RequestMethod.POST)
	public List<Profile> create(@RequestBody Profile profile){
		profileRepository.insert(profile);
		
		return profileRepository.findAll();
	}
	
	@RequestMapping(value="/delete/{id}", method=RequestMethod.POST)
	public List<Profile> delete(@PathVariable String id){
		profileRepository.deleteById(id);
		
		return profileRepository.findAll();
	}
	

}
