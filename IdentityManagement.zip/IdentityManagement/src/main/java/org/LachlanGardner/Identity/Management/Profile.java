package org.LachlanGardner.Identity.Management;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

@Document
public class Profile {
	
	@Id
	private String id;
	private String firstName;
	private String lastName;
	private String username;
	private String password;
	private String email;
	private String role;
	
	public Profile() {}

	public Profile(String firstName, String lastName, String username, String password, String email, String role) {
		this.firstName = firstName;
		this.lastName = lastName;
		this.username = username;
		this.password = password;
		this.email = email;
		this.role = role;
	}

	public String getId() {
		return id;
	}

	public String getFirstName() {
		return firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public String getUsername() {
		return username;
	}

	public String getPassword() {
		return password;
	}

	public String getEmail() {
		return email;
	};
	
	public String getRole() {
		return role;
	};
	
	
	
}
