package org.LachlanGardner.Identity.Management;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

@Controller
public class LoginController {
	
	
	private ProfileRepository profileRepository;
	
	@Autowired
	public void BookingController(ProfileRepository profileRepository) {
		this.profileRepository = profileRepository;
	}
	
	//to get login form page
	@RequestMapping(value="/login", method=RequestMethod.GET)
	public String getLoginForm() {
		// return html page name
		return "login";
	}
	
	//checking for login credentials
	@RequestMapping(value="/login", method=RequestMethod.POST)
	public String login(@ModelAttribute(name="loginform") LoginForm loginForm, Model model) {
		
		String username = loginForm.getUsername();
		String password = loginForm.getPassword();
		
		List<Profile> profiles = new ArrayList<Profile>();
		profiles = profileRepository.findAll();
		
		
		for(int i = 0; i < profiles.size(); i++) {
			if(profiles.get(i).getUsername().equals(username) && profiles.get(i).getPassword().equals(password)) {
				//if username and password are correct, we are returning home page
				return "home";
			}
		}
		
		//if username or password is incorrect
		model.addAttribute("invalidCredentials", true);
		//returning again login page
		return "login";
	}

}
